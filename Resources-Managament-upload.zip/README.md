# Resources Managament

This folder is the standalone Discord bot and clothing showcase command.
It does not load `bot.py` or settings from Virtual-Designs-Management.

## Setup on Windows

```powershell
cd "Resources Managament"
copy .env.example .env
# Open .env and replace both values before starting the bot.
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py
```

Put the Discord bot token in `.env` as `DISCORD_TOKEN`. Do not share that file.
Upload this entire folder (including `bot.py`, `clothing_showcase.py`, and
`assets`) to your hosting service. Set the host startup command to
`python run.py` or `py run.py`.

## Clothing commands

- `/showcase-clothing`: upload one to four clothing templates and choose
  **Landscape** or **Portrait**. An optional background upload applies only to
  that showcase.
- `/showcase-background`: managers can upload a default background or provide
  an HTTPS image URL. Run it with no image or URL to clear the default.

The generated image is sent as `clothing-showcase.png`. The bot needs
`View Channels`, `Send Messages`, `Attach Files`, and `Use Application Commands`.

## Files to upload

Do upload: `bot.py`, `clothing_showcase.py`, `run.py`,
`requirements.txt`, `.env`, and `assets/`.

Do not upload: `.venv/`, `__pycache__/`, or any file containing a token other
than the private `.env` file.
