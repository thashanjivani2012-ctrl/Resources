"""Clothing template showcase commands.

The image composition is intentionally kept separate from the command wiring so
the feature can also be reused by the standalone launcher in Resources Managament.
"""

from __future__ import annotations

import io
import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

import discord
from discord import app_commands

try:
    from PIL import Image, ImageDraw, ImageFont, ImageOps
except ImportError:  # pragma: no cover - reported when the command is used
    Image = ImageDraw = ImageFont = ImageOps = None

SETTINGS_FILE = None
ASSETS_DIR = None
LOG = logging.getLogger("order-center.clothing-showcase")
MAX_IMAGE_BYTES = 12 * 1024 * 1024
LANDSCAPE_SIZE = (1600, 900)
PORTRAIT_SIZE = (1080, 1350)


def setup(bot, settings_file: Path, assets_dir: Path):
    global SETTINGS_FILE, ASSETS_DIR
    SETTINGS_FILE = settings_file
    ASSETS_DIR = assets_dir


def _read_settings() -> dict:
    if SETTINGS_FILE is None or not SETTINGS_FILE.exists():
        return {}
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_settings(data: dict):
    if SETTINGS_FILE is None:
        raise RuntimeError("Showcase settings are not configured.")
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _settings(guild: discord.Guild) -> dict:
    settings = _read_settings()
    return settings.setdefault(str(guild.id), {})


def _font(size: int, bold: bool = False):
    candidates = [
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


async def _attachment_bytes(attachment: discord.Attachment) -> bytes:
    if attachment.size > MAX_IMAGE_BYTES:
        raise ValueError(f"{attachment.filename} is larger than the {MAX_IMAGE_BYTES // 1024 // 1024} MB limit.")
    data = await attachment.read()
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError(f"{attachment.filename} is larger than the {MAX_IMAGE_BYTES // 1024 // 1024} MB limit.")
    return data


def _url_bytes(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "Resources-Managament-Showcase/1.0"})
    with urllib.request.urlopen(request, timeout=15) as response:
        data = response.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError("The background URL points to an image larger than 12 MB.")
    return data


def _open_image(data: bytes):
    if Image is None:
        raise RuntimeError("Pillow is not installed. Run `pip install -r requirements.txt`.")
    with Image.open(io.BytesIO(data)) as image:
        return image.convert("RGBA")


def _fit(image, box: tuple[int, int, int, int]):
    left, top, right, bottom = box
    fitted = ImageOps.contain(image, (right - left, bottom - top))
    return fitted, (left + (right - left - fitted.width) // 2, top + (bottom - top - fitted.height) // 2)


def _compose(images: list, orientation: str, title: str, background):
    width, height = LANDSCAPE_SIZE if orientation == "landscape" else PORTRAIT_SIZE
    canvas = Image.new("RGBA", (width, height), (245, 203, 218, 255))
    if background is not None:
        bg = ImageOps.fit(background, (width, height))
        canvas.alpha_composite(bg)
    draw = ImageDraw.Draw(canvas)
    margin = 52
    title_font = _font(58 if orientation == "landscape" else 52, bold=True)
    title_text = title.strip()[:50] or "CLOTHING SHOWCASE"
    title_box = draw.textbbox((0, 0), title_text, font=title_font)
    draw.text(((width - (title_box[2] - title_box[0])) // 2, 28), title_text, fill="white", font=title_font, stroke_width=2, stroke_fill=(90, 48, 65))

    content_top = 118
    gap = 24
    columns = 2 if orientation == "landscape" else 1
    rows = (len(images) + columns - 1) // columns
    card_width = (width - (2 * margin) - gap * (columns - 1)) // columns
    card_height = (height - content_top - margin - gap * (rows - 1)) // rows
    for index, image in enumerate(images):
        column, row = index % columns, index // columns
        x = margin + column * (card_width + gap)
        y = content_top + row * (card_height + gap)
        card = (x, y, x + card_width, y + card_height)
        draw.rounded_rectangle(card, radius=18, fill=(255, 255, 255, 235), outline="white", width=5)
        fitted, position = _fit(image, (x + 12, y + 12, x + card_width - 12, y + card_height - 12))
        canvas.alpha_composite(fitted, position)
    return canvas


async def _background_for(guild: discord.Guild, override: Optional[discord.Attachment]):
    if override is not None:
        return _open_image(await _attachment_bytes(override))
    saved = _settings(guild).get("background_path")
    if saved:
        path = Path(saved)
        if path.exists():
            return _open_image(path.read_bytes())
    return None


@app_commands.command(name="showcase-clothing", description="Create a landscape or portrait clothing showcase")
@app_commands.describe(
    template_1="The first clothing template image",
    template_2="Optional second template image",
    template_3="Optional third template image",
    template_4="Optional fourth template image",
    orientation="Choose the showcase layout",
    title="Heading shown above the templates",
    background="Optional one-time background override",
)
@app_commands.choices(orientation=[
    app_commands.Choice(name="Landscape", value="landscape"),
    app_commands.Choice(name="Portrait", value="portrait"),
])
@app_commands.guild_only()
async def showcase_clothing(
    interaction: discord.Interaction,
    template_1: discord.Attachment,
    orientation: app_commands.Choice[str],
    template_2: Optional[discord.Attachment] = None,
    template_3: Optional[discord.Attachment] = None,
    template_4: Optional[discord.Attachment] = None,
    title: str = "CLOTHING SHOWCASE",
    background: Optional[discord.Attachment] = None,
):
    await interaction.response.defer()
    try:
        images = [_open_image(await _attachment_bytes(item)) for item in (template_1, template_2, template_3, template_4) if item]
        bg = await _background_for(interaction.guild, background)
        output = _compose(images, orientation.value, title, bg)
        buffer = io.BytesIO()
        output.convert("RGB").save(buffer, format="PNG", optimize=True)
        buffer.seek(0)
        await interaction.followup.send(
            content=f"**{title.strip()[:50] or 'CLOTHING SHOWCASE'}** — {orientation.name} layout",
            file=discord.File(buffer, filename="clothing-showcase.png"),
        )
    except (OSError, ValueError, RuntimeError) as error:
        LOG.warning("Showcase composition failed: %s", error)
        await interaction.followup.send(f"I couldn't create the showcase: {error}", ephemeral=True)


@app_commands.command(name="showcase-background", description="Set or clear the default clothing showcase background")
@app_commands.describe(image="Upload a background image", url="HTTPS image URL, or leave both blank to clear it")
@app_commands.default_permissions(manage_guild=True)
@app_commands.guild_only()
async def showcase_background(
    interaction: discord.Interaction,
    image: Optional[discord.Attachment] = None,
    url: Optional[str] = None,
):
    if not interaction.user.guild_permissions.manage_guild and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("You need **Manage Server** to change the showcase background.", ephemeral=True)
        return
    if image is not None and url:
        await interaction.response.send_message("Choose an upload or a URL, not both.", ephemeral=True)
        return
    settings = _settings(interaction.guild)
    if image is None and not url:
        settings.pop("background_path", None)
        data = _read_settings()
        data[str(interaction.guild.id)] = settings
        _write_settings(data)
        await interaction.response.send_message("The default showcase background was cleared.", ephemeral=True)
        return
    try:
        data = await _attachment_bytes(image) if image is not None else _url_bytes(url.strip())
        _open_image(data)
        directory = Path(ASSETS_DIR) / "showcase"
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"background-{interaction.guild.id}.png"
        path.write_bytes(data)
        settings["background_path"] = str(path)
        data = _read_settings()
        data[str(interaction.guild.id)] = settings
        _write_settings(data)
    except (OSError, ValueError, RuntimeError, urllib.error.URLError) as error:
        LOG.warning("Could not save showcase background: %s", error)
        await interaction.response.send_message(f"I couldn't save that background: {error}", ephemeral=True)
        return
    await interaction.response.send_message("The default clothing showcase background was updated.", ephemeral=True)


COMMANDS = [showcase_clothing, showcase_background]
